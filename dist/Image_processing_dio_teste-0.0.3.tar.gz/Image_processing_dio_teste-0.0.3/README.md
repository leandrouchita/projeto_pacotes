# Image Processing

Description. 
The package image-Processing is used to:
## Processing:
- Histrogram matching
- Structural similarity
- Resize image
## Ultils:
- Read image
- Save image
- Plot image
- Plot results
- Plot histograms

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install image_processing

```bash
pip install image_processing
```
## Author
karina

## License
[MIT](https://choosealicense.com/licenses/mit/)